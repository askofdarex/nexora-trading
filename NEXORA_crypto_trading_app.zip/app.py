import os
import json
import time
import threading
from datetime import datetime, timezone
from pathlib import Path

import requests
from flask import Flask, jsonify, render_template, request

APP_DIR = Path(__file__).resolve().parent
DATA_FILE = APP_DIR / "paper_state.json"
app = Flask(__name__, static_folder="static", template_folder="templates")

DEFAULT_STATE = {
    "starting_balance": 1000.0,
    "cash": 1000.0,
    "positions": [],
    "trades": [],
    "settings": {
        "strategy": "ema_momentum",
        "auto_trade": False,
        "paper_mode": True,
        "symbols": ["BTCUSDT", "ETHUSDT", "SOLUSDT"],
        "timeframe": "15m",
        "risk_per_trade_pct": 1.0,
        "max_daily_loss_pct": 3.0,
        "stop_loss_pct": 2.0,
        "take_profit_pct": 4.0
    },
    "daily_realized_pnl": 0.0,
    "daily_key": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
    "last_scan": None,
    "last_signals": [],
    "bot_message": "Paper trading is ready. Automation is OFF."
}

state_lock = threading.RLock()
bot_thread = None
bot_stop = threading.Event()
PRICE_CACHE = {"at": 0, "prices": {}}

def load_state():
    if DATA_FILE.exists():
        try:
            state = json.loads(DATA_FILE.read_text())
            # Ensure new settings exist if a saved file is older.
            for k, v in DEFAULT_STATE.items():
                if k not in state:
                    state[k] = v
            for k, v in DEFAULT_STATE["settings"].items():
                state["settings"].setdefault(k, v)
            return state
        except Exception:
            pass
    return json.loads(json.dumps(DEFAULT_STATE))

state = load_state()

def save_state():
    DATA_FILE.write_text(json.dumps(state, indent=2))

def get_prices(force=False):
    now = time.time()
    if not force and now - PRICE_CACHE["at"] < 10 and PRICE_CACHE["prices"]:
        return PRICE_CACHE["prices"]
    symbols = state["settings"]["symbols"]
    prices = {}
    try:
        # Public Binance spot ticker endpoint. No account/API key is used.
        r = requests.get(
            "https://api.binance.com/api/v3/ticker/price",
            params={"symbols": json.dumps(symbols)},
            timeout=8
        )
        r.raise_for_status()
        data = r.json()
        prices = {x["symbol"]: float(x["price"]) for x in data}
        PRICE_CACHE.update({"at": now, "prices": prices})
    except Exception:
        # Return the last known public prices if the endpoint is temporarily unavailable.
        prices = PRICE_CACHE.get("prices", {})
    return prices

def get_klines(symbol, interval="15m", limit=100):
    r = requests.get(
        "https://api.binance.com/api/v3/klines",
        params={"symbol": symbol, "interval": interval, "limit": limit},
        timeout=8
    )
    r.raise_for_status()
    rows = r.json()
    return [{
        "time": int(row[0] / 1000),
        "open": float(row[1]),
        "high": float(row[2]),
        "low": float(row[3]),
        "close": float(row[4]),
        "volume": float(row[5])
    } for row in rows]

def ema(values, period):
    if len(values) < period:
        return None
    alpha = 2 / (period + 1)
    value = sum(values[:period]) / period
    for x in values[period:]:
        value = alpha * x + (1 - alpha) * value
    return value

def rsi(values, period=14):
    if len(values) <= period:
        return None
    gains, losses = [], []
    for i in range(1, len(values)):
        change = values[i] - values[i - 1]
        gains.append(max(change, 0))
        losses.append(max(-change, 0))
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def build_signal(symbol):
    try:
        candles = get_klines(symbol, state["settings"]["timeframe"], 100)
        closes = [c["close"] for c in candles]
        if len(closes) < 55:
            return {"symbol": symbol, "signal": "WAIT", "reason": "Not enough candle data"}
        fast = ema(closes, 20)
        slow = ema(closes, 50)
        momentum_rsi = rsi(closes, 14)
        price = closes[-1]
        if fast is None or slow is None or momentum_rsi is None:
            return {"symbol": symbol, "signal": "WAIT", "reason": "Indicators warming up"}
        # Educational baseline only; not a validated profitable strategy.
        if fast > slow and 50 <= momentum_rsi <= 68 and price > fast:
            signal, reason = "BUY", "EMA20 above EMA50; momentum confirmed"
        elif fast < slow and momentum_rsi < 45 and price < fast:
            signal, reason = "SELL", "Downtrend and weak momentum (exit long if held)"
        else:
            signal, reason = "WAIT", "No complete setup"
        return {
            "symbol": symbol, "signal": signal, "reason": reason,
            "price": price, "ema20": fast, "ema50": slow, "rsi": momentum_rsi,
            "candle_time": candles[-1]["time"]
        }
    except Exception as e:
        return {"symbol": symbol, "signal": "WAIT", "reason": "Market data unavailable"}

def total_equity(prices):
    with state_lock:
        equity = state["cash"]
        for pos in state["positions"]:
            equity += pos["qty"] * prices.get(pos["symbol"], pos["entry_price"])
        return equity

def close_position(position_id, price, reason):
    with state_lock:
        pos = next((p for p in state["positions"] if p["id"] == position_id), None)
        if not pos:
            return False
        pnl = (price - pos["entry_price"]) * pos["qty"]
        state["cash"] += pos["qty"] * price
        state["daily_realized_pnl"] += pnl
        trade = {
            "id": pos["id"], "symbol": pos["symbol"], "side": "LONG",
            "entry_price": pos["entry_price"], "exit_price": price,
            "qty": pos["qty"], "pnl": pnl, "reason": reason,
            "opened_at": pos["opened_at"],
            "closed_at": datetime.now(timezone.utc).isoformat()
        }
        state["trades"].insert(0, trade)
        state["positions"] = [p for p in state["positions"] if p["id"] != position_id]
        save_state()
        return True

def open_position(symbol, price):
    with state_lock:
        if any(p["symbol"] == symbol for p in state["positions"]):
            return False, "Position already open"
        settings = state["settings"]
        equity = total_equity(get_prices())
        max_loss = equity * (settings["max_daily_loss_pct"] / 100)
        if state["daily_realized_pnl"] <= -max_loss:
            return False, "Daily loss limit reached"
        risk_cash = equity * settings["risk_per_trade_pct"] / 100
        stop_pct = settings["stop_loss_pct"] / 100
        if price <= 0 or stop_pct <= 0:
            return False, "Invalid risk settings"
        qty = risk_cash / (price * stop_pct)
        # Limit position notional to 25% of current cash to avoid excessive concentration.
        qty = min(qty, (state["cash"] * 0.25) / price)
        notional = qty * price
        if qty <= 0 or notional > state["cash"]:
            return False, "Insufficient simulated cash"
        state["cash"] -= notional
        position = {
            "id": f"paper-{int(time.time() * 1000)}",
            "symbol": symbol, "qty": qty, "entry_price": price,
            "stop_price": price * (1 - settings["stop_loss_pct"] / 100),
            "take_profit_price": price * (1 + settings["take_profit_pct"] / 100),
            "opened_at": datetime.now(timezone.utc).isoformat()
        }
        state["positions"].append(position)
        save_state()
        return True, "Paper position opened"

def manage_positions(prices):
    with state_lock:
        positions = list(state["positions"])
        settings = state["settings"]
    for pos in positions:
        price = prices.get(pos["symbol"])
        if not price:
            continue
        if price <= pos["stop_price"]:
            close_position(pos["id"], price, "Stop-loss")
        elif price >= pos["take_profit_price"]:
            close_position(pos["id"], price, "Take-profit")

def reset_daily_if_needed():
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    with state_lock:
        if state.get("daily_key") != today:
            state["daily_key"] = today
            state["daily_realized_pnl"] = 0.0
            save_state()

def bot_loop():
    while not bot_stop.is_set():
        reset_daily_if_needed()
        prices = get_prices(force=True)
        if prices:
            manage_positions(prices)
        with state_lock:
            enabled = state["settings"]["auto_trade"]
            symbols = list(state["settings"]["symbols"])
        signals = [build_signal(s) for s in symbols]
        with state_lock:
            state["last_scan"] = datetime.now(timezone.utc).isoformat()
            state["last_signals"] = signals
            if enabled:
                opened = []
                for sig in signals:
                    if sig.get("signal") == "BUY" and sig.get("price"):
                        ok, msg = open_position(sig["symbol"], sig["price"])
                        if ok:
                            opened.append(sig["symbol"])
                state["bot_message"] = (
                    "Paper bot running. Opened: " + ", ".join(opened)
                    if opened else "Paper bot running. No new entries this scan."
                )
            else:
                state["bot_message"] = "Scanner running; automated entries are OFF."
            save_state()
        bot_stop.wait(60)

def start_background_thread():
    global bot_thread
    if bot_thread and bot_thread.is_alive():
        return
    bot_stop.clear()
    bot_thread = threading.Thread(target=bot_loop, daemon=True)
    bot_thread.start()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/overview")
def overview():
    prices = get_prices()
    with state_lock:
        positions = [dict(p) for p in state["positions"]]
        trades = [dict(t) for t in state["trades"][:50]]
        settings = dict(state["settings"])
        signals = list(state["last_signals"])
        cash = state["cash"]
        starting = state["starting_balance"]
        daily = state["daily_realized_pnl"]
        message = state["bot_message"]
        last_scan = state["last_scan"]
    for p in positions:
        current = prices.get(p["symbol"], p["entry_price"])
        p["current_price"] = current
        p["unrealized_pnl"] = (current - p["entry_price"]) * p["qty"]
    equity = cash + sum(p["qty"] * p["current_price"] for p in positions)
    return jsonify({
        "starting_balance": starting, "cash": cash, "equity": equity,
        "total_pnl": equity - starting, "daily_realized_pnl": daily,
        "prices": prices, "positions": positions, "trades": trades,
        "settings": settings, "signals": signals,
        "bot_message": message, "last_scan": last_scan,
        "server_time": datetime.now(timezone.utc).isoformat()
    })

@app.route("/api/scan", methods=["POST"])
def scan():
    with state_lock:
        symbols = list(state["settings"]["symbols"])
    signals = [build_signal(s) for s in symbols]
    with state_lock:
        state["last_signals"] = signals
        state["last_scan"] = datetime.now(timezone.utc).isoformat()
        save_state()
    return jsonify({"signals": signals})

@app.route("/api/settings", methods=["POST"])
def update_settings():
    payload = request.get_json(silent=True) or {}
    allowed = {"risk_per_trade_pct", "max_daily_loss_pct", "stop_loss_pct", "take_profit_pct", "timeframe"}
    with state_lock:
        for key in allowed:
            if key in payload:
                try:
                    value = float(payload[key]) if key != "timeframe" else str(payload[key])
                    if key != "timeframe" and not (0.1 <= value <= 20):
                        return jsonify({"error": f"{key} must be between 0.1 and 20"}), 400
                    state["settings"][key] = value
                except (TypeError, ValueError):
                    return jsonify({"error": f"Invalid {key}"}), 400
        save_state()
    return jsonify({"ok": True, "settings": state["settings"]})

@app.route("/api/automation", methods=["POST"])
def automation():
    payload = request.get_json(silent=True) or {}
    enabled = bool(payload.get("enabled", False))
    with state_lock:
        state["settings"]["auto_trade"] = enabled
        state["settings"]["paper_mode"] = True
        state["bot_message"] = (
            "Paper automation enabled. Real-money trading is not connected."
            if enabled else "Paper automation disabled."
        )
        save_state()
    start_background_thread()
    return jsonify({"ok": True, "enabled": enabled, "message": state["bot_message"]})

@app.route("/api/close/<position_id>", methods=["POST"])
def close_one(position_id):
    prices = get_prices(force=True)
    with state_lock:
        pos = next((p for p in state["positions"] if p["id"] == position_id), None)
    if not pos:
        return jsonify({"error": "Position not found"}), 404
    price = prices.get(pos["symbol"], pos["entry_price"])
    close_position(position_id, price, "Manual close")
    return jsonify({"ok": True})

@app.route("/api/reset", methods=["POST"])
def reset():
    with state_lock:
        state.clear()
        state.update(json.loads(json.dumps(DEFAULT_STATE)))
        save_state()
    return jsonify({"ok": True})

if __name__ == "__main__":
    # Start scanner on launch; automation remains OFF unless the user enables paper trading.
    start_background_thread()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
