# NEXORA — AI Crypto Terminal (paper-trading starter)

NEXORA is a mobile-friendly web app starter for testing a basic crypto strategy with a **$1,000 simulated balance**. It uses public Binance spot market data and does not connect to any account or place real-money orders.

## Features
- Mobile-friendly dark dashboard
- Public BTC/USDT, ETH/USDT and SOL/USDT spot prices
- BTC hourly price chart
- EMA20 / EMA50 + RSI14 strategy signal scanner
- Simulated long positions, stop-loss and take-profit monitoring
- Risk settings and trade history
- Paper automation starts OFF
- No exchange keys, deposits, withdrawals, or live order execution

## Run locally
Requires Python 3.10+.

```bash
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000` in a browser.

## Deploy
This Flask app can be deployed to a Python-compatible host, but free hosting may sleep or restart and may not support persistent background tasks. The JSON state file may also be lost on ephemeral hosting. For reliable 24/7 use, a persistent database and a continuously running worker are needed. Do not assume a free deployment will run continuously.

## Important
This is an experimental educational baseline, not financial advice and not a profitable strategy claim. The signal conditions have not been independently validated. Paper trading may differ from live execution due to fees, slippage, latency, liquidity, and exchange restrictions. Test and backtest thoroughly before considering real funds.
